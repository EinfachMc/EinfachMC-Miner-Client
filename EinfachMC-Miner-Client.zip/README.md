# EinfachMC-Miner-Client
Was schaut ihr so ich bin noch net fertig ._.

-----

# Fragen?
  Schau bitte erst **[hier](https://github.com/EinfachMc/EinfachMC-Miner-Client/wiki)** vorbei. Wenn du da nichts findest frag               EinfachAlexYT#2379 oder Lee#6874 auf [Discord](http://discord.einfachmc.de/)
